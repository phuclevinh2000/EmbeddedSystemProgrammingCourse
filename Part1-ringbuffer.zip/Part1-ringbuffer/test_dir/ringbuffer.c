#include "ringbuffer.h"

void init_buffer(struct buffer_type *b, unsigned char *buffer)
{
    b->head = buffer;
    b->tail = buffer;
    b->buffer = buffer;
}

// void get_buffer_state(struct buffer_type *b, unsigned char *buffer)
// {
//     b->head = buffer;
//     b->tail = buffer;
//     b->buffer = buffer;
// }