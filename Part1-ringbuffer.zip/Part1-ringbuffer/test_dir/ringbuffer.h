/* ringbuffer.h */

#define MAX_BUFFER 1024

struct buffer_type
{
    unsigned char *head;
    unsigned char *tail;
    unsigned char *buffer;

};


enum error_type {OK, BUFFER_OVER_FLOW, EMPTY_BUFFER, POINTER_ERROR, BUFFER_FULL};


void init_buffer(struct buffer_type *b, unsigned char *buffer);

