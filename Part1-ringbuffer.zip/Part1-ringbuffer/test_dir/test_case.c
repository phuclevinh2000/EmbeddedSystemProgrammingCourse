/* test_case.c*/
#include <gtest/gtest.h>
#include "ringbuffer.h"

TEST(init_category, basic_test)
{
    unsigned char rx_buffer[MAX_BUFFER]="abcdef";
    struct buffer_type r;

    r.tail = rx_buffer+10;
    init_buffer(&r, rx_buffer);

    EXPECT_EQ(r.head, rx_buffer);
    EXPECT_EQ(r.tail, rx_buffer+10);
    EXPECT_EQ(r.buffer, rx_buffer);


    /**** Same testcases using C assertion

    init_buffer(&b,buff);

    assert(b.head==buff);
    assert(b.tail==buff);
    assert(b.buffer==buff);
    */
}

// TEST(C_get_buffer_state,basic_test)
// {
//     unsigned char rx_buffer[MAX_BUFFER];
//     struct buffer_type r;

//     int state;
//     error_type err;

//     r.buffer=rx_buffer;

//   /* set some condition that simulates a some situation      */
//   /* For this function content of the buffer does not matter */
//     r.head=rx_buffer+15;       /* OR  r.head=&rx_buffer[15]; */
//     r.tail=rx_buffer+2;

//     state=get_buffer_state(&r,&err);

//  /* Expected result */
//     EXPECT_EQ(state, 13);
//     EXPECT_EQ(err, OK);

//  /* These should not have moved at all*/
//     EXPECT_EQ(r.head, rx_buffer+15);
//     EXPECT_EQ(r.tail, rx_buffer+2);
//     EXPECT_EQ(r.buffer, rx_buffer);

// }