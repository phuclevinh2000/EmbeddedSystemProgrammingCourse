float calc_average(float data[], int size);
