#include <stdio.h>
#include "my_math.h"

int main(void)
{
	float data[]={2,3};
	float val;

	printf("Main release version of program\n ready to be released to customers\n");

	val=calc_average(data,2);

}
